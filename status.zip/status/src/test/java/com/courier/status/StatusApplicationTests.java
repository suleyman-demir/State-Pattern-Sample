package com.courier.status;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatusApplicationTests {

	@Test
	void contextLoads() {
	}

}
